./hello.py --greeter1=morning:Hal --morning.intro="Waz up" --greeter2.intro="Yo" --name="George"
./hello.py --greeter1=morning:Hal --greeter1.intro="Waz up" --greeter2.intro="Yo" --name="George"
./hello.py --greeter1=morning:Hal --greeter1.intro="Waz up" --greeter2=morning:Lou --greeter2.intro="Yo" --name="George"
