#!/usr/bin/env python
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#
#                             Michael A.G. Aivazis
#                      California Institute of Technology
#                      (C) 1998-2005  All Rights Reserved
#
# {LicenseText}
#
# ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#

class FileLocking(object):


    LOCK_EX = 0
    LOCK_SH = 0
    LOCK_NB = 0


    def lock(self, stream, flags):
        return


    def unlock(self, stream):
        return


# version
__id__ = "$Id: FileLocking.py,v 1.1.1.1 2006-11-27 00:10:05 aivazis Exp $"

# End of file 
