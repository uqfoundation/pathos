#!/usr/bin/env python
# Parallel Python setup script
# For the latest version of the Parallel Python
# software visit: http://www.parallelpython.com
"""
Standard build tool for python libraries.
"""

import os.path
try:
#   import __force_distutils__ #XXX: uncomment to force use of distutills
    from setuptools import setup
    has_setuptools = True
except ImportError:
    from distutils.core import setup
    has_setuptools = False

from pp import __version__ as VERSION


LONG_DESCRIPTION = """
Parallel Python module (PP) provides an easy and efficient way to create \
parallel-enabled applications for SMP computers and clusters. PP module \
features cross-platform portability and dynamic load balancing. Thus \
application written with PP will parallelize efficiently even on \
heterogeneous and multi-platform clusters (including clusters running other \
application with variable CPU loads). Visit http://www.parallelpython.com \
for further information.
"""


setup_code = """
setup(
        name="pp",
        url="http://www.parallelpython.com",
        version=VERSION,
        download_url="http://dev.danse.us/packages/"
        author="Vitalii Vanovschi",
        author_email="support@parallelpython.com",
        py_modules=["ppworker", "pptransport", "ppauto", "pp"],
        scripts=["ppserver.py"],
        description="Parallel and distributed programming for Python",
        platforms=["Windows", "Linux", "Unix"],
        long_description=LONG_DESCRIPTION,
        license="BSD-like",
        classifiers=[
        "Topic :: Software Development",
        "Topic :: System :: Distributed Computing",
        "Programming Language :: Python",
        "Operating System :: OS Independent",
        "License :: OSI Approved :: BSD License",
        "Natural Language :: English",
        "Intended Audience :: Developers",
        "Development Status :: 5 - Production/Stable",
        ],
"""

# add dependencies
dill_version = '>=0.1a1'
if has_setuptools:
    setup_code += """
        zip_safe = False,
        install_requires = ['dill%s'],
""" % dill_version

# close 'setup' call
setup_code += """
)
"""

# exec the 'setup' code
exec setup_code

# if dependencies are missing, print a warning
try:
    import dill
except ImportError:
    print "\n***********************************************************"
    print "WARNING: One of the following dependencies is unresolved:"
    print "    dill (optional) %s" % dill_version
    print "***********************************************************\n"

if __name__=='__main__':
    pass

# End of file
